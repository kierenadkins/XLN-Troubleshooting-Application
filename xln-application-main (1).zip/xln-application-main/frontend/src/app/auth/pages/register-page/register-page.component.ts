import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-register-page',
  templateUrl: './register-page.component.html',
  styleUrls: ['./register-page.component.scss']
})
export class RegisterPageComponent implements OnInit {

  alreadyLoggedIn: boolean = false
  registerForm = new FormGroup({
    first_name: new FormControl('', [Validators.required]),
    last_name: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    username: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required])
  })

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.checkStatus()
  }

  checkStatus() {
    this.alreadyLoggedIn = this.authService.isLoggedIn()
  }

  onSubmit() {
    if(!this.registerForm.valid) return

    this.authService.createNewAccount(
      this.registerForm.value
    ).pipe(
      catchError(err => {
        
        return throwError(() => err)
      })
    ).subscribe(result => {
      console.log(result)
      this.router.navigate(['/auth/login'])
    })
  }

}
