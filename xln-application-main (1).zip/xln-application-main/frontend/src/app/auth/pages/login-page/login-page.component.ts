import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../auth.service';
import { catchError } from 'rxjs/operators'
import { throwError } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {

  alreadyLoggedIn = false
  err!: string
  loginForm = new FormGroup({
    email: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
  })

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.checkStatus()
  }

  checkStatus() {
    this.alreadyLoggedIn = this.authService.isLoggedIn()
  }

  onSubmit() {
    if(!this.loginForm.valid) return

    this.authService.attemptLogin(this.loginForm.value.email, this.loginForm.value.password).pipe(catchError(err => {
      // error
      this.checkStatus()
      if(err.status === 401){
        this.err = 'Incorrect username or password!'
      }
      this.loginForm.controls['password'].reset()
      return throwError(err)
    })).subscribe(() => {
      //this.checkStatus()
      this.router.navigate(['/'])
      window.location.reload();
    })
  }

  logout() {
    this.authService.logout()
    this.checkStatus()
  }

}
