import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BaseAuthPageComponent } from './base-auth-page.component';

describe('BaseAuthPageComponent', () => {
  let component: BaseAuthPageComponent;
  let fixture: ComponentFixture<BaseAuthPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BaseAuthPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BaseAuthPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
