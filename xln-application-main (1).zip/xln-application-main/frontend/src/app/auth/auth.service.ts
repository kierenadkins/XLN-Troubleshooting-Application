import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { share, catchError, throwError, BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';
import { removeToken, setToken } from './utils';

export interface LoginResponse {
  access: string
  refresh: string
}

export interface Profile {
  id?: number
  email?: string
  username?: string
}

export interface Token {
  token_type?: string
  jti?: number
  exp?: number
  iat?: number

  user_id?: number
  username?: string
  name?: string
  admin?: boolean
  account_type?: 'customer' | 'admin' | 'reviewer'
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  authenticationStatus: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false)

  constructor(private httpClient: HttpClient, private jwtHelperService: JwtHelperService) {
    this.sendUpdate()
  }

  attemptLogin(username: string, password: string) {
    let observable = this.httpClient.post<LoginResponse>(`${environment.baseApiUrl}/auth/token/`, {
      username,
      password
    }).pipe(share())

    observable.pipe(
      catchError(err => {
        return throwError(err)
      })
    ).subscribe(response => {
      if(response.access) {
        setToken(response.access)
      }

      this.sendUpdate()
    })

    return observable
  }

  sendUpdate() {
    this.authenticationStatus.next(this.isLoggedIn())
  }

  logout() {
    removeToken()
    this.sendUpdate()
  }

  /*getProfile() {
    return this.httpClient.get<Profile>(`${environment.baseApiUrl}/auth/profile/`)
  }*/

  isLoggedIn() {
    if(this.jwtHelperService.tokenGetter() ?? null !== null) {
      if(this.jwtHelperService.isTokenExpired()) {
        removeToken()
        return false
      }
      return true
    }
    return false
  }

  createNewAccount(options: any) {
    return this.httpClient.post(`${environment.baseApiUrl}/auth/register/`, options)
  }

  getProfile() {
    return this.jwtHelperService.decodeToken<Token>()
  }
}
