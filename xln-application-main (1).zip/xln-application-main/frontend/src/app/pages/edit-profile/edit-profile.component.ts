import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Profile } from 'src/app/api/api.service';
import { ApiService } from 'src/app/api/api.service';



@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss']
})

export class EditProfileComponent implements OnInit {

  profile!: Profile;
  displayName: string;

  editProfileForm = new FormGroup({
    first_name: new FormControl(''),
    last_name:new FormControl(''),
    username:new FormControl(''),
    email: new FormControl(''),
    //password: new FormControl('')

  })
  hide = true;
  constructor(private apiService: ApiService, private router: Router) { }

  ngOnInit(): void {
    this.apiService.getProfile().subscribe(profile => {
      this.profile = profile
      this.displayName = profile.first_name + " " + profile.last_name;
    })
  }

  onSubmit() {
    console.log(this.profile)
    this.apiService.updateAccount(this.editProfileForm.value).subscribe(profile => {
      
    })
    this.router.navigate(['/profile']);
  }

}
