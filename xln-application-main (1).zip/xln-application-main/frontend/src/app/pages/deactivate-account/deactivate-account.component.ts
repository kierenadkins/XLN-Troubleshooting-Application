import {Component, Inject} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { ApiService } from 'src/app/api/api.service';
import { DeleteWarningComponent } from 'src/app/components/delete-warning/delete-warning.component';

export interface DialogData {
  animal: string;
  name: string;
}

/**
 * @title Dialog Overview
 */
 @Component({
  selector: 'app-deactivate-account',
  templateUrl: './deactivate-account.component.html',
  styleUrls: ['./deactivate-account.component.scss']
})
export class DeactivateAccountComponent {
  form: any;
  
  constructor(public dialog: MatDialog, private apiService: ApiService, private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.apiService.createReviewerAccount(null);
    
     this.form = this.formBuilder.group({
     username : this.formBuilder.control('', Validators.required),
     })
    }
    

  openDialog(): void {
    const dialogRef = this.dialog.open(DeleteWarningComponent, {
      width: '250px',
  
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result){
        this.apiService.deleteAccount(this.form.value.username).subscribe(() => {

        })
      }
      
    });

   
  }
     onSubmit(){
      this.apiService.deleteAccount(this.form.value.username).subscribe(() => {

      })
    }

  
}