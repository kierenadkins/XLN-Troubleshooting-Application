import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { catchError, throwError } from 'rxjs';
import { ApiService } from 'src/app/api/api.service';

@Component({
  selector: 'app-create-reviewer',
  templateUrl: './create-reviewer.component.html',
  styleUrls: ['./create-reviewer.component.scss']
})
export class CreateReviewerComponent implements OnInit {
  form: any
  hasSubmissionError: boolean;
  displayValue: string
  submitted: boolean = false

  constructor(private apiService:ApiService, private formBuilder: FormBuilder) {
    
  }
  

 ngOnInit(): void {
   this.apiService.createReviewerAccount(null);
   
    this.form = this.formBuilder.group({
    first_name : this.formBuilder.control('', Validators.required),
    last_name: this.formBuilder.control('', Validators.required),
    username: this.formBuilder.control('', Validators.required),
    email: this.formBuilder.control('', Validators.required),
    password: this.formBuilder.control('', Validators.required),
    
  })
  
 }
 
 onSubmit() {
   this.apiService.createReviewerAccount(this.form.value).subscribe(account => {

   },
   err => {
     return throwError(() => err)
   },
   () => this.submitted = true
   )
 }


}
