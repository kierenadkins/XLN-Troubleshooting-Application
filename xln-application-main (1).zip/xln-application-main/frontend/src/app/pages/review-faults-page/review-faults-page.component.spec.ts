import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewFaultsPageComponent } from './review-faults-page.component';

describe('ReviewFaultsPageComponent', () => {
  let component: ReviewFaultsPageComponent;
  let fixture: ComponentFixture<ReviewFaultsPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReviewFaultsPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewFaultsPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
