import { Component, OnInit } from '@angular/core';
import { ApiService, Fault } from 'src/app/api/api.service';

@Component({
  selector: 'app-review-faults-page',
  templateUrl: './review-faults-page.component.html',
  styleUrls: ['./review-faults-page.component.scss']
})
export class ReviewFaultsPageComponent implements OnInit {

  faults: Fault[] = [];
  isStaff: boolean;

  constructor(private apiService:ApiService ) {}

  ngOnInit(): void {
    this.apiService.getProfile().subscribe(profile => {
      this.isStaff = profile.is_staff || profile.account_type === 'admin' || profile.account_type === 'reviewer'
      this.getFaults();
    })
    
  }

  getFaults() {
    this.apiService.getCustomerFaults().subscribe(faults => {
      this.faults = faults
      console.log(faults)
    });
  }
}
