import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

export interface Response {
  text: string
}


@Injectable({
  providedIn: 'root'
})
export class ChatbotService {

  constructor(private http: HttpClient) { }

  getResponse(text: string) {
    return this.http.post<Response>(`${environment.baseApiUrl}/chatbot`, { text })
  }
}
