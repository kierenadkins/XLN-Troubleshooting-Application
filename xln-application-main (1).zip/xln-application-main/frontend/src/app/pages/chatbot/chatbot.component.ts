import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Route } from '@angular/router';
import { catchError, throwError, timeout } from 'rxjs';
import { ChatbotService } from './chatbot.service';

@Component({
  selector: 'app-chatbot',
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})
export class ChatbotComponent implements OnInit {

  @ViewChild('messageContainer') messageContainer: ElementRef

  fullscreen = false
  loading = false
  form = new FormGroup({
    message: new FormControl('', []),
  })

  messages = [
    {
      user: null,
      text: 'Hello! Please enter your query below and we\'ll try to help.'
    }
  ]

  constructor(private chatbotService: ChatbotService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.url.subscribe(url => {
      if(url[0].path === "chatbot") {
        this.fullscreen = true
      }
    })
    
  }

  scrollToBottom() {
    setTimeout(() =>this.messageContainer.nativeElement.scrollTop = this.messageContainer.nativeElement.scrollHeight, 200)
  }

  onSubmit() {
    if(!this.form.value.message) return;

    this.loading = true
    this.scrollToBottom()

    let message = this.form.value.message
    this.messages.push({
      user: 1234,
      text: message
    })

    this.form.reset()

    this.chatbotService.getResponse(message).pipe(catchError(err => {
      this.loading = false
      this.scrollToBottom()
      return throwError(() => err)
    })).subscribe(res => {
      this.loading = false
      this.scrollToBottom()
      this.messages.push({
        user: null,
        text: res.text
      })
    })
  }

}
