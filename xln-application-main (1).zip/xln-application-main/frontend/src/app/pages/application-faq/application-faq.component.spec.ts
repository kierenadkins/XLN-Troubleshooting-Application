import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationFAQComponent } from './application-faq.component';

describe('ApplicationFAQComponent', () => {
  let component: ApplicationFAQComponent;
  let fixture: ComponentFixture<ApplicationFAQComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApplicationFAQComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationFAQComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
