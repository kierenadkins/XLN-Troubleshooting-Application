import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-application-faq',
  templateUrl: './application-faq.component.html',
  styleUrls: ['./application-faq.component.scss']
})
export class ApplicationFAQComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
