import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, Form } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ApiService, Appointment, Service, Fault } from 'src/app/api/api.service';
import { catchError, throwError } from 'rxjs';

@Component({
  selector: 'request-form',
  templateUrl: './request-appointment-page.component.html',
  styleUrls: ['./request-appointment-page.component.scss']
})
export class AppointmentFormComponent implements OnInit {
  form: FormGroup
  submitted: boolean = false
  hasSubmissionError: boolean = false
  appointment: Appointment;

  faults: Fault[] = [];
  isStaff: boolean;

  appointmentTimes = ["9:00 AM","10:00 AM","11:00 AM","1:00 PM","2:00 PM","3:00 PM","4:00 PM"]
 
  constructor(
    private http: HttpClient,
    private formBuilder: FormBuilder,
    private router: Router,
    private apiService: ApiService) {}

  ngOnInit() {
    this.form = this.formBuilder.group({
      fault: this.formBuilder.control('', Validators.required),
      date: this.formBuilder.control('', Validators.required),
      time: this.formBuilder.control('', Validators.required),
      location1: this.formBuilder.control('', Validators.required),
      location2: this.formBuilder.control('')
    })
    this.apiService.getProfile().subscribe(profile => {
      this.isStaff = profile.is_staff;
      this.getFaults();
    })
  }

  getFaults() {
    if (this.isStaff) {
      console.log(this.isStaff)
      this.apiService.getStaffFaults().subscribe(faults => {
        this.faults = faults
        console.log(faults)
      });
    } else {
      console.log("not staff")
      this.apiService.getCustomerFaults().subscribe(faults => {
        this.faults = faults
        console.log(faults)
      });
    }
  }

  onSubmit() {
    this.apiService.submitAppointment(this.form.value).subscribe(appointment => {
      console.log(appointment)
    },
    err => {
      return throwError(() => err)
    },
    () => this.submitted = true
    )
  }
}