import { Component, OnInit } from '@angular/core';
import { ApiService, Appointment, Fault } from 'src/app/api/api.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  faults: Fault[] = [];
  appointments: Appointment[] = [];
  inProgress: Fault[] = [];
  reviewed: Fault[] = [];
  showAssigned: boolean = false;
  userId: number;

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.getFaults();
    this.getAppointments();
    this.apiService.getProfile().subscribe(profile => {
      this.userId = profile.id;
    })
  }

  toggleAssigned(event) {
    this.showAssigned = event.checked;
    this.getFaults();
  }

  checkReviewers(fault: Fault) {
    let contains: boolean = false;
    fault.assigned_reviewers.forEach(reviewer => {
      if (reviewer.id == this.userId) contains = true;
    });

    return contains;
  }

  getFaults() {
    this.apiService.getFaults().toPromise().then(faults => {
      this.faults = faults.filter(f => f.status == "default").reverse();
      this.inProgress = faults.filter(f => f.status == "inProgress").reverse();
      this.reviewed = faults.filter(f => f.status == "reviewed").reverse();
      console.log(faults);
    })
  }

  getAppointments() {
    this.apiService.getAppointments().toPromise().then(appointments => {
      this.appointments = appointments;
      console.log(this.appointments);
    })
  }
}
