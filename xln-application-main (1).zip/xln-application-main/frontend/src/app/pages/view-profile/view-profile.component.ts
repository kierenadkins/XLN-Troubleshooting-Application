import { Component, OnInit } from '@angular/core';
import { ApiService, Profile } from 'src/app/api/api.service';
import { AuthService } from 'src/app/auth/auth.service';



@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.scss']
})
export class ViewProfileComponent implements OnInit {
  profile:Profile = null

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.apiService.getProfile().subscribe(profile => {
      this.profile = profile
    })
  }

}
