import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiService, Fault, Profile, Response } from 'src/app/api/api.service';
import { AuthService } from 'src/app/auth/auth.service';
import { ImageComponent } from 'src/app/components/attach-image/attach-image.component';


@Component({
  selector: 'app-view-fault',
  templateUrl: './view-fault.component.html',
  styleUrls: ['./view-fault.component.scss']
})
export class ViewFaultComponent implements OnInit {
  @ViewChild('uploadImages') uploadImageComponent: ImageComponent;
  currentId: number;
  isStaff: boolean;
  assigned: boolean;
  profile: Profile;

  statuses = [
    {name: 'default', text: 'Not Started'},
    {name: 'inProgress', text: 'In Progress'},
    {name: 'reviewed', text: 'Reviewed'},
  ];

  priorities = [
    {name: 1, text: 'Not Urgent'},
    {name: 2, text: 'Important'},
    {name: 3, text: 'Urgent'},
  ];

  message: string;
  faultId: number;
  fault: Fault = {};
  response: Response = {};
  //status = new FormControl();
  selectedStatus: string;
  selectedPriority: number;

  editFaultForm = new FormGroup({
    assigned: new FormControl(false),
    status: new FormControl(''),
    priority: new FormControl(''),
  })

  createResponseForm = new FormGroup({
    message: new FormControl('')
  })

  constructor(private authService: AuthService, private apiService: ApiService, private router: ActivatedRoute) { }

  ngOnInit(): void {
    this.router.queryParams.subscribe(params=>{
      this.faultId = params['id']

      this.apiService.getProfile().subscribe(profile => {
        this.profile = profile;
        this.isStaff = profile.is_staff || profile.account_type === 'admin' || profile.account_type === 'reviewer'
        this.getFault()
      })
    })
    
  }

  getFault() {
    this.apiService.getFault(this.faultId).toPromise().then(fault => {
      this.fault = fault;
      this.assigned = fault.assigned_reviewers.findIndex(ar => ar.id == this.profile.id) !== -1
      this.selectedStatus = fault.status;
      this.selectedPriority = fault.priority;
    })
  }

  submitResponse() {
    this.response.fault = this.fault.id;
    this.response.message = this.message;
    this.uploadImageComponent.uploadFiles().subscribe(() => {
      let images = this.uploadImageComponent.getIds()      
      this.apiService.submitResponse({
        images,
        ...this.response
      }).toPromise().then(r => {
        this.message = "";
        this.getFault();
        this.uploadImageComponent.clearFiles();
      })
    })
  }

  assignedChange(event) {
    let assign = event.checked;
    let assignedIds = [];
    this.fault.assigned_reviewers.map((x) => {
      assignedIds.push(x.id)
    })  
    console.log("Original " + assignedIds);
    if (assign) {
      if (assignedIds.includes(this.profile.id)) return;
      assignedIds.push(this.profile.id);
      console.log("Updated " + assignedIds);
    } else {
      if (assignedIds.includes(this.profile.id)) {
        let index = assignedIds.indexOf(this.profile.id);
        assignedIds.splice(index, 1);
      }
    }
    this.fault.new_assigned_reviewers = assignedIds
    this.updateFault();
  }

  statusChange(event: string) {
    this.fault.status = event;
    this.updateFault();
  }

  priorityChange(event: number) {
    this.fault.priority = event;
    this.updateFault();
  }

  updateFault() {
    console.log("assigned " + this.fault.new_assigned_reviewers)
    console.log(this.fault)
    this.apiService.updateFault(this.fault).toPromise().then(r => {
      this.getFault();
    })
  }

}
