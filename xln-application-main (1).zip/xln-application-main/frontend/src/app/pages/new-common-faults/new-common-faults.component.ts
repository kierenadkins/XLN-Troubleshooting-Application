import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-common-faults',
  templateUrl: './new-common-faults.component.html',
  styleUrls: ['./new-common-faults.component.scss']
})
export class NewCommonFaultsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
