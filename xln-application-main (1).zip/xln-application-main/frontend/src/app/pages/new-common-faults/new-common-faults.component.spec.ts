import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewCommonFaultsComponent } from './new-common-faults.component';

describe('NewCommonFaultsComponent', () => {
  let component: NewCommonFaultsComponent;
  let fixture: ComponentFixture<NewCommonFaultsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewCommonFaultsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewCommonFaultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
