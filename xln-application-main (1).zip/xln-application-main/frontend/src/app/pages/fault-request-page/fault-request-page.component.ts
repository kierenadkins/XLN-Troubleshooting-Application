import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder, Form } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ApiService, Service } from 'src/app/api/api.service';
import { catchError, throwError } from 'rxjs';
import { ImageComponent } from 'src/app/components/attach-image/attach-image.component';

@Component({
  selector: 'fault-form',
  templateUrl: './fault-request-page.component.html',
  styleUrls: ['./fault-request-page.component.scss']
})
export class FaultFormComponent implements OnInit {
  @ViewChild('uploadImages') uploadImageComponent: ImageComponent

  form: FormGroup
  submitted: boolean = false
  hasSubmissionError: boolean = false

  services = ["Broadband", "Fixed line", "iPBX"]

  broadbandFaults = ["Router","Browsing","Tariffs","Card Machine","Authentication"]
  fixedLineFaults = ["Ringing","Dial Tone","Call Failure","Sound Quality"]
  iPBXFaults = ["Making And Receiving Calls","Call Quality","Device","Internal Networking","Voicemail","Phone Book","Automated Assistant","Recording","Login","Time Schedule"]

  constructor(
    private http: HttpClient,
    private formBuilder: FormBuilder,
    private router: Router,
    private apiService: ApiService) {}

  ngOnInit() {
    this.form = this.formBuilder.group({
      service: this.formBuilder.control('', Validators.required),
      type: this.formBuilder.control('', Validators.required),
      title: this.formBuilder.control('', Validators.required),
      priority: this.formBuilder.control('', Validators.required),
      message: this.formBuilder.control(''),
    })
  }

  onSubmit() {
    this.uploadImageComponent.uploadFiles().subscribe(() => {
      let images = this.uploadImageComponent.getIds()
      this.apiService.submitFault({
        images,
        ...this.form.value
      }).pipe(catchError(err => {
        this.hasSubmissionError = true
  
        return throwError(() => err)
      })).subscribe(fault => {
        this.submitted = true
      })
    })
  }
}