import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

export interface Service {
  id: number
  name: string
}

export interface Profile {
  id?: number
  first_name?: string
  last_name?: string
  email?: string
  is_staff?: boolean
  account_type?: 'customer' | 'admin' | 'reviewer'
  username?: string
  customer_key?: string
  broadband_number?: string
  phone_number?: string
  services?: Service[]
}

export interface Fault {
  id?: number
  customer?: Profile
  assigned_reviewers?: Profile[]
  new_assigned_reviewers?: number[]
  status?: string
  service?: string
  type?: string
  priority?: number
  created?: string
  title?: string
  message?: string
  images?: string[] 
  responses?: Response[]
}

export interface Response {
  id?: number
  fault?: number
  user?: Profile
  created?: string
  message?: string
  images?: string[]
}

export interface Image {
  id: number
  file: string
  created: string
}

export interface Appointment {
  id: number
  customer: Profile
  fault: Fault
  date: string
  time: string
  location1: string
  location2: string
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  getProfile() {
    return this.http.get<Profile>(`${environment.baseApiUrl}/profile/`)
  }

  getStaff() {
    return this.http.get<Profile[]>(`${environment.baseApiUrl}/staff/`)
  }

  getFaults() {
    return this.http.get<Fault[]>(`${environment.baseApiUrl}/faults/`)
  }

  getFault(id: number) {
    return this.http.get<Fault>(`${environment.baseApiUrl}/faults/${id}`)
  }

  submitFault(fault: Fault) {
    return this.http.post<Fault>(`${environment.baseApiUrl}/faults/`, JSON.stringify(fault), {headers : new HttpHeaders({ 'Content-Type': 'application/json' })})
  }

  submitImage(image: FormData) {
    return this.http.post<Image>(`${environment.baseApiUrl}/images/`, image)
  }
  createReviewerAccount(options: any) {
    return this.http.post(`${environment.baseApiUrl}/auth/register/reviewer/`, options)
  }

  updateAccount(options: any) {
    return this.http.patch(`${environment.baseApiUrl}/auth/account/`, options)
  }

  deleteAccount(username: string) {
    return this.http.delete(`${environment.baseApiUrl}/deactivate/${username}/`)
  }

  submitAppointment(appointment: Appointment) {
    return this.http.post<Appointment>(`${environment.baseApiUrl}/appointments/`, JSON.stringify(appointment), {headers : new HttpHeaders({ 'Content-Type': 'application/json' })})
  }

  submitResponse(response: Response) {
    return this.http.post<Response>(`${environment.baseApiUrl}/responses/`, JSON.stringify(response), {headers : new HttpHeaders({ 'Content-Type': 'application/json' })})
  }

  updateFault(fault: Fault) {
    let updatedFault: Fault | any = fault
    delete updatedFault.images
    updatedFault.assigned_reviewers = updatedFault.new_assigned_reviewers;
    
    return this.http.patch<Fault>(`${environment.baseApiUrl}/faults/${fault.id}/`, JSON.stringify(updatedFault), {headers: new HttpHeaders({ 'Content-Type': 'application/json' })})
  }

  getCustomerFaults() {
    return this.http.get<Fault[]>(`${environment.baseApiUrl}/customer-faults/`)
  }

  getStaffFaults() {
    return this.http.get<Fault[]>(`${environment.baseApiUrl}/staff-faults/`)
  }

  getAppointments() {
    return this.http.get<Appointment[]>(`${environment.baseApiUrl}/appointments/`)
  }
}
