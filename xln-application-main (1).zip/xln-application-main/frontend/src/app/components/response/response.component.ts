import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Fault } from 'src/app/api/api.service';
import { Response } from 'src/app/api/api.service';
import { AuthService } from 'src/app/auth/auth.service';
import { FullScreenImageComponent } from '../full-screen-image/full-screen-image.component';

@Component({
  selector: 'app-response',
  templateUrl: './response.component.html',
  styleUrls: ['./response.component.scss']
})
export class ResponseComponent implements OnInit {

  @Input() response?: Response;
  @Input() customerId?: number;
  isCurrentUser: boolean = false;
  currentId: number;

  constructor(public dialog: MatDialog, private authService: AuthService) { }

  ngOnInit(): void {
    this.currentId = this.authService.getProfile().user_id;
    if (this.response.user.id == this.currentId) {
      this.isCurrentUser = true;
    }
  }

  openDialog() {
    const dialogRef = this.dialog.open(FullScreenImageComponent, {
      width: "100%",
      height: "100%",
      data: { images: this.response.images }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }
}
