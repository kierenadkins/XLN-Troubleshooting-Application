import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { preserveWhitespacesDefault } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { MatDrawer, MatSidenav } from '@angular/material/sidenav';
import { Router, RoutesRecognized } from '@angular/router';
import { Observable, map, shareReplay } from 'rxjs';
import { filter, pairwise } from 'rxjs/operators';
import { AuthService } from 'src/app/auth/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  loggedIn: boolean = false
  routes = [
    {
      name: 'Home',
      icon: 'home',
      url: '/',
      exact: true
    },
    {
      name: 'Account',
      icon: 'account_circle',
      url: '/profile',
      exact: true
    },
    {
      name: 'New Fault',
      icon: 'create',
      url: '/faults/new'
    },
    {
      name: 'My Faults',
      icon: 'errors',
      url: '/myfaults'
    },
    {
      name: 'Request Appointment',
      icon: 'calendar_today',
      url: '/appointment'
    },
    {
      name: 'Reviewer Dashboard',
      icon: 'view_compact',
      url: '/reviewer-dashboard'
    },
    {
      name: 'Create',
      icon: 'create',
      url: '/Create/Review'
    },
    {
      name: 'Delete',
      icon: 'delete',
      url: '/Delete/Review'
    },
    {
      name: 'Find us',
      icon: 'map',
      url: '/FindUs'
    },
    {
      name: 'Help',
      icon: 'help',
      url: '/troubleshooting'
    },
  ]

  constructor(private router: Router, private authService: AuthService, private breakpointObserver: BreakpointObserver) {}

  ngOnInit(): void {
    this.authService.authenticationStatus.subscribe(loggedIn => this.loggedIn = loggedIn)

    let accountType = this.authService.getProfile()?.account_type
    if(accountType == "customer"){

      this.routes = [
        {
          name: 'Home',
          icon: 'home',
          url: '/',
          exact: true
        },
        {
          name: 'Account',
          icon: 'account_circle',
          url: '/profile',
          exact: true
        },
        {
          name: 'New Fault',
          icon: 'create',
          url: '/faults/new'
        },
        {
          name: 'My Faults',
          icon: 'errors',
          url: '/myfaults'
        },
        {
          name: 'Request Appointment',
          icon: 'calendar_today',
          url: '/appointment'
        },
        {
          name: 'Find us',
          icon: 'map',
          url: '/FindUs'
        },
        {
          name: 'Help',
          icon: 'help',
          url: '/troubleshooting'
        },
      ]
     
        
    }
    else if(accountType == "reviewer"){
    
      this.routes = [
        {
          name: 'Home',
          icon: 'home',
          url: '/',
          exact: true
        },
        {
          name: 'Account',
          icon: 'account_circle',
          url: '/profile',
          exact: true
        },
        {
          name: 'Reviewer Dashboard',
          icon: 'view_compact',
          url: '/reviewer-dashboard'
        },
        {
        
          name: 'Help',
          icon: 'help',
          url: '/troubleshooting'
        },
      ]
   
    }
    else if(accountType == "admin"){
     
      this.routes = [
        {
          name: 'Home',
          icon: 'home',
          url: '/',
          exact: true
        },
        {
          name: 'Account',
          icon: 'account_circle',
          url: '/profile',
          exact: true
        },
        {
          name: 'Reviewer Dashboard',
          icon: 'view_compact',
          url: '/reviewer-dashboard'
        },
        {
          name: 'Create',
          icon: 'create',
          url: '/Create/Review'
        },
        {
          name: 'Delete',
          icon: 'delete',
          url: '/Delete/Review'
        },
        {
        
          name: 'Help',
          icon: 'help',
          url: '/troubleshooting'
        },
      ]
 
    }
    else {
      this.routes = [
        {
          name: 'Home',
          icon: 'home',
          url: '/',
          exact: true
        },
        {
          name: 'Find us',
          icon: 'map',
          url: '/FindUs'
        },
        {
          
          name: 'Help',
          icon: 'help',
          url: '/troubleshooting'
        },
      ]
  
    } 

  }

  // Determine if the device is being viewed on a handset (used by the menu to choose how to display)
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  getCurrentRoute() {
    return this.router.url;
  }

  toggle(nav: MatDrawer) {
    const isSmallScreen = this.breakpointObserver.isMatched(
      "(max-width: 600px)"
    );
    if (isSmallScreen) {
      (nav.toggle());
    }
    else {
      
    }
  }


  getPreviousRoute() {
    var prev;
    this.router.events
    .pipe(filter((evt: any) => evt instanceof RoutesRecognized), pairwise())
    .subscribe((events: RoutesRecognized[]) => {
      prev = events[0].urlAfterRedirects.toString();
    });
    return prev;

  }

  logout() {
    this.authService.logout()
    this.router.navigate(['/'])
    window.location.reload();
    this.router.navigate(['/'])
    
    
  }
  login() {
    this.router.navigate(['/auth/login'])
    
  }
  signup() {
    this.router.navigate(['/auth/register'])
  }
  profile() {
    this.router.navigate(['/profile'])
  }

}
