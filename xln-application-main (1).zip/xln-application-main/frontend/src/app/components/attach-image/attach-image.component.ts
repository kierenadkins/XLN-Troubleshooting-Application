import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, Validators, FormBuilder, Form } from '@angular/forms';
import { ApiService } from 'src/app/api/api.service';
import { BehaviorSubject, forkJoin, observable, Observable, Subscription } from 'rxjs';
  
@Component({
  selector: 'app-attach-image',
  templateUrl: './attach-image.component.html',
  styleUrls: ['./attach-image.component.scss']
})
export class ImageComponent implements OnInit {
  @ViewChild('uploadButton') uploadButton: ElementRef
   form: FormGroup
   //submitted: boolean = false
   //hasSubmissionError: boolean = false
   ids = []
   files = []
   images = []

   constructor(
       private apiService: ApiService,
       private formBuilder: FormBuilder) {}
   ngOnInit() {
    this.form = this.formBuilder.group({
        file: new FormControl(''),
        fileSource: new FormControl('')
    })
   }
   
  get f(){
    return this.form.controls;
  }
   
  onFileChange(event) {
    if (event.target.files && event.target.files[0]) {
        let filesAmount = event.target.files.length;
        for (let i = 0; i < filesAmount; i++) {
                this.files.push(event.target.files[i])

                let reader = new FileReader();
   
                reader.onload = (event:any) => {
                  console.log(event.target.result);
                   this.images.push(event.target.result); 
   
                   this.form.patchValue({
                      fileSource: this.images
                   });
                }
  
                reader.readAsDataURL(event.target.files[i]);
                console.log(this.files)
        }
    }
  }
  @ViewChild("uploadField") uploadField;
  focusOnUpload() {
    this.uploadField.nativeElement.focus();
  }

  clearFiles(){
    this.uploadField.nativeElement.value = ''
    this.files = []
    this.images = []
    this.ids = []
  }

  uploadFiles() {
    if (this.files.length == 0) return new BehaviorSubject(null);
    let tasks = []
    this.files.forEach(file => {
      let formData: FormData = new FormData()
      formData.append('file', file)
      let observable = this.apiService.submitImage(formData)
      observable.subscribe(image => {
        this.ids.push(image.id)
      })
      tasks.push(observable)
    })

    this.clearFiles();
    return forkJoin(tasks)
  }

  getIds() {
    return this.ids
  }
}