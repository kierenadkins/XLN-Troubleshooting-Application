import { Component, Inject, Input, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import SwiperCore, { Navigation, Keyboard, Pagination } from "swiper";

SwiperCore.use([Navigation, Keyboard, Pagination]);

@Component({
  selector: 'app-full-screen-image',
  templateUrl: './full-screen-image.component.html',
  styleUrls: ['./full-screen-image.component.scss']
})
export class FullScreenImageComponent implements OnInit {

  @Input() images: string[] = [];
  fakeArray = new Array(this.images.length);
  
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
    this.images = this.data.images
    console.log(this.data.images)
  }

}
