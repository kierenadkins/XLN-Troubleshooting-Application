import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FaultPreviewComponent } from './fault-preview.component';

describe('FaultPreviewComponent', () => {
  let component: FaultPreviewComponent;
  let fixture: ComponentFixture<FaultPreviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FaultPreviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FaultPreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
