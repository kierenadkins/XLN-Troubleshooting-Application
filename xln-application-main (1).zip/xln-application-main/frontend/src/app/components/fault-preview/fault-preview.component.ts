import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService, Fault, Profile } from 'src/app/api/api.service';

@Component({
  selector: 'app-fault-preview',
  templateUrl: './fault-preview.component.html',
  styleUrls: ['./fault-preview.component.scss']
})
export class FaultPreviewComponent implements OnInit {

  @Input() fault: Fault;
  reviewers = new FormControl();
  isStaff: boolean;
  staffList: Profile[];
  selectedStaff = [];
 
  assignReviewersForm: FormGroup = new FormGroup({
    reviewers: new FormControl()
  })

  constructor(private router: Router, private apiService: ApiService) { }

  ngOnInit(): void {
    // for (let i = 0; i < this.fault.assigned_reviewers.length; i++) {
    //   this.selectedStaff.push(i)
    // }
    this.selectedStaff = this.fault.assigned_reviewers.map(ar => ar.id)

    this.apiService.getProfile().subscribe(profile => {
      this.isStaff = profile.is_staff || profile.account_type === 'admin' || profile.account_type === 'reviewer'
    })

    this.apiService.getStaff().subscribe(staff => {
      this.staffList = staff

    });
  }

  viewFault() {
    this.router.navigate(['view-fault'],{queryParams:{id:this.fault.id}});
  }

  reviewersChange(event) {
    let newReviewers = []
    console.log(event)
    // for (let i = 0; i < event.reviewers.length; i++) {
    //   let n = i;
    //   newReviewers.push(i);
    // }
    event.map(reviewer => {
      newReviewers.push(reviewer)
    })
    this.fault.new_assigned_reviewers = newReviewers
    this.apiService.updateFault(this.fault).subscribe(() => {})
  }

  onSubmit() {
    
  }

  isAssigned(id: number) {
    let found = false
    this.fault?.assigned_reviewers.forEach(ar => {
      if(ar.id === id) found = true
    })
    return found
  }
}
