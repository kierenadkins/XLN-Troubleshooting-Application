import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, map, shareReplay } from 'rxjs';

@Component({
  selector: 'app-chatbot-button',
  templateUrl: './chatbot-button.component.html',
  styleUrls: ['./chatbot-button.component.scss']
})
export class ChatbotButtonComponent implements OnInit {

  miniChatbotOpen = false

  constructor(private router: Router, private breakpointObserver: BreakpointObserver) { }

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  isHandset = false

  ngOnInit(): void {
    this.isHandset$.subscribe(isHandset => {
      this.isHandset = isHandset
    })
  }

  openChatbot() {
    if(this.isHandset) {
      this.router.navigate(['/chatbot'])
      return
    } else {
      this.miniChatbotOpen = true
    }
  }

  closeChatbot() {
    this.miniChatbotOpen = false
  }

}
