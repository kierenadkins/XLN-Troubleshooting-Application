import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatbot-message',
  templateUrl: './chatbot-message.component.html',
  styleUrls: ['./chatbot-message.component.scss']
})
export class ChatbotMessageComponent implements OnInit {

  @Input('message') message: string
  @Input('self') userMessage: boolean
  
  constructor() { }

  ngOnInit(): void {
  }

}