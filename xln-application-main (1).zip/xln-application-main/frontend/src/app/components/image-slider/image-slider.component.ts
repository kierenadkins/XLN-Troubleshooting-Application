import { Component, Input, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import SwiperCore, { Navigation, Keyboard, Pagination } from "swiper";
import {MatDialog} from '@angular/material/dialog';
import { FullScreenImageComponent } from '../full-screen-image/full-screen-image.component';

SwiperCore.use([Navigation, Keyboard, Pagination]);

@Component({
  selector: 'app-image-slider',
  templateUrl: './image-slider.component.html',
  styleUrls: ['./image-slider.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ImageSliderComponent implements OnInit {

  @Input() images: string[];

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialog(image: string) {
    const dialogRef = this.dialog.open(FullScreenImageComponent, {
      width: "100%",
      height: "100%",
      data: { images: this.images }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

}
