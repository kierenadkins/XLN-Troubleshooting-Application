import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HttpClientModule } from '@angular/common/http';
import { ChatbotButtonComponent } from './components/chatbot-button/chatbot-button.component';
import { CreateReviewerComponent } from './pages/create-reviewer/create-reviewer.component';
import { DeactivateAccountComponent } from './pages/deactivate-account/deactivate-account.component';
import { DeleteWarningComponent } from './components/delete-warning/delete-warning.component';
import { FaultFormComponent } from './pages/fault-request-page/fault-request-page.component';
import { JwtModule } from '@auth0/angular-jwt';
import { getToken } from './auth/utils';
import { environment } from 'src/environments/environment';
import { AuthModule } from './auth/auth.module';
import { ViewProfileComponent } from './pages/view-profile/view-profile.component';
import { EditProfileComponent } from './pages/edit-profile/edit-profile.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ChatbotComponent } from './pages/chatbot/chatbot.component';
import { ChatbotMessageComponent } from './components/chatbot-messages/chatbot-message.component';
import { ReviewFaultsPageComponent } from './pages/review-faults-page/review-faults-page.component';
import { DashboardComponent } from './pages/reviewer/dashboard/dashboard.component';
import { FaultPreviewComponent } from './components/fault-preview/fault-preview.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { ViewFaultComponent } from './pages/view-fault/view-fault.component';
import { ResponseComponent } from './components/response/response.component';
import { SwiperModule } from "swiper/angular";
import { ImageSliderComponent } from './components/image-slider/image-slider.component';
import { FullScreenImageComponent } from './components/full-screen-image/full-screen-image.component';
import { ImageComponent } from './components/attach-image/attach-image.component';
import { NewCommonFaultsComponent } from './pages/new-common-faults/new-common-faults.component';
import { PageFooterComponent } from './components/page-footer/page-footer.component';
import { ErrorPageComponent } from './pages/error-page/error-page.component';
import { AppointmentFormComponent } from './pages/request-appointment-page/request-appointment-page.component';
import { FindUsComponent } from './pages/find-us/find-us.component';
import { ApplicationFAQComponent } from './pages/application-faq/application-faq.component';
import { AppointmentPreviewComponent } from './components/appointment-preview/appointment-preview.component';



@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    NavbarComponent,
    ChatbotButtonComponent,
    CreateReviewerComponent,
    DeactivateAccountComponent,
    DeleteWarningComponent,
    FaultFormComponent,
    ViewProfileComponent,
    EditProfileComponent,
    ChatbotComponent,
    ChatbotMessageComponent,
    ReviewFaultsPageComponent,
    DashboardComponent,
    FaultPreviewComponent,
    ViewFaultComponent,
    ResponseComponent,
    ImageSliderComponent,
    FullScreenImageComponent,
    ImageComponent,
    NewCommonFaultsComponent,
    PageFooterComponent,
    ErrorPageComponent,
    AppointmentFormComponent,
    FindUsComponent,
    ApplicationFAQComponent,
    AppointmentPreviewComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MaterialModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: getToken,
        allowedDomains: [environment.baseApiUrl.replace(/^https?:\/\//, '')]
      },
    }),
    AuthModule,
    ReactiveFormsModule,
    SwiperModule
  ],
  providers: [],
  exports: [
    ReactiveFormsModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
