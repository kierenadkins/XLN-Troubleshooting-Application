import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChatbotComponent } from './pages/chatbot/chatbot.component';
import { HomePageComponent } from './pages/home-page/home-page.component';

import { CreateReviewerComponent } from './pages/create-reviewer/create-reviewer.component';
import { DeactivateAccountComponent } from './pages/deactivate-account/deactivate-account.component';
import { EditProfileComponent } from './pages/edit-profile/edit-profile.component';
import { FaultFormComponent } from './pages/fault-request-page/fault-request-page.component';
import { ViewProfileComponent } from './pages/view-profile/view-profile.component';
import { ReviewFaultsPageComponent } from './pages/review-faults-page/review-faults-page.component';
import { DashboardComponent } from './pages/reviewer/dashboard/dashboard.component'
import { ViewFaultComponent } from './pages/view-fault/view-fault.component';
import { AuthGuard } from './auth/auth.guard';
import { ImageComponent } from './components/attach-image/attach-image.component';
import { NewCommonFaultsComponent } from './pages/new-common-faults/new-common-faults.component';
import { ErrorPageComponent } from './pages/error-page/error-page.component';
import { AppointmentFormComponent } from './pages/request-appointment-page/request-appointment-page.component';
import { FindUsComponent } from './pages/find-us/find-us.component';
import { ApplicationFAQComponent } from './pages/application-faq/application-faq.component';


const routes: Routes = [
  {
    path: 'auth',
    loadChildren: () => import('./auth/auth-routing.module').then(m => m.AuthRoutingModule)
  },
  { path: '', pathMatch: 'full', component: HomePageComponent },
  { path: 'profile', pathMatch: 'full', component: ViewProfileComponent ,canActivate: [AuthGuard]},
  { path: 'edit-profile', pathMatch: 'full', component: EditProfileComponent ,canActivate: [AuthGuard] },
  { path: 'reviewer-dashboard', pathMatch: 'full', component: DashboardComponent ,canActivate: [AuthGuard] },
  { path: 'view-fault', pathMatch: 'full', component: ViewFaultComponent ,canActivate: [AuthGuard]},
  { path: 'Create/Review', pathMatch: 'full', component: CreateReviewerComponent,canActivate: [AuthGuard] },
  { path: 'Delete/Review', pathMatch: 'full', component: DeactivateAccountComponent,canActivate: [AuthGuard] },
  { path: 'faults/new', component: FaultFormComponent, canActivate: [AuthGuard] },
  { path: 'profile', pathMatch: 'full', component: ViewProfileComponent , canActivate: [AuthGuard]},
  { path: 'edit-profile', pathMatch: 'full', component: EditProfileComponent, canActivate: [AuthGuard] },
  { path: 'myfaults', pathMatch: 'full', component: ReviewFaultsPageComponent , canActivate: [AuthGuard]},
  { path: 'troubleshooting', pathMatch: 'full', component: NewCommonFaultsComponent },
  { path: 'profile', pathMatch: 'full', component: ViewProfileComponent,canActivate: [AuthGuard] },
  { path: 'edit-profile', pathMatch: 'full', component: EditProfileComponent,canActivate: [AuthGuard] },
  { path: 'reviewer-dashboard', pathMatch: 'full', component: DashboardComponent,canActivate: [AuthGuard] },
  { path: 'image', pathMatch: 'full', component: ImageComponent },
  { path: 'appointment', pathMatch: 'full', component: AppointmentFormComponent,canActivate: [AuthGuard] },
  { path: 'chatbot', pathMatch: 'full', component: ChatbotComponent },
  { path: 'FindUs', pathMatch: 'full', component: FindUsComponent },
  { path: 'applicationFaq', pathMatch: 'full', component: ApplicationFAQComponent },
  { path: '**', pathMatch: 'full', component: ErrorPageComponent,}
  
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }//