import textdistance

def TrainingRun():
  f = open("Question.txt", "r")
  Questions = f.read().split('","')
  f.close()
  f = open("Answer.txt", "r")
  Answers = f.read().split('","')
  f.close()

  userinput = input("Enter message user would send to chatbot (press enter to exit): ").lower()
  while(userinput!=""):

    similarities = []
    for i in range(len(Questions)):
        roSim = textdistance.ratcliff_obershelp.normalized_similarity(userinput, Questions[i])
        jwSim = textdistance.jaro_winkler.normalized_similarity(userinput, Questions[i])
        similarities.append((roSim+jwSim)/2)

    maxSimIndex = similarities.index(max(similarities))

    print("\nChatbot Recognised Message:",Questions[maxSimIndex].replace(r'\n', '\n').replace('"',""))
    print("\nChatbot Response:",Answers[maxSimIndex].replace(r'\n', '\n').replace('"',""))

    chatbotCheck = str(input("\nWould deem this as an adequate recognition and response. Please enter yes or no: ")).lower()
    while (chatbotCheck!="yes" and chatbotCheck!="no"):
        chatbotCheck = str(input("Please enter yes or no: ")).lower()
    if(chatbotCheck=="no"):
        confirmed = False
        while(confirmed==False):
            useranswer = str(input("Please enter the response you would like users to recieve instead: "))
            print("\nUser Message:",userinput)
            print("\nChatbot Response:",useranswer,"\n")
            userConfirm = str(input("Do you confirm this chatbot addition. Please enter yes or no: ")).lower()
            while (userConfirm!="yes" and userConfirm!="no"):
                userConfirm = str(input("Please enter yes or no: ")).lower()
            if(userConfirm=="yes"):
                confirmed = True
        f = open("Question.txt", "a")
        AddQuestion = f.write(',"'+userinput+'"')
        f.close()
        Questions.append(userinput)
        f = open("Answer.txt", "a")
        AddAnswer = f.write(',"'+useranswer+'"')
        f.close()
        Answers.append(useranswer)
        print("Addition Saved")
    
    print("Thanks For Your Support")

    userinput = input("\nEnter message user would send to chatbot (press enter to exit): ").lower()

TrainingRun()