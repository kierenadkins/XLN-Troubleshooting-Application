from cgitb import text
from rest_framework.generics import GenericAPIView
from rest_framework.response import Response
from rest_framework.exceptions import ParseError
from .serializers import ChatSerializer
from .models import Conversation
from . import chatbot

class ChatbotView(GenericAPIView):
    serializer_class = ChatSerializer

    def post(self, request, *args, **kwargs):
        form = self.get_serializer(data=request.data)
        if not form.is_valid():
            raise ParseError(detail="No valid values")

        conversation = None

        if self.request.user.is_authenticated:
            conversation = Conversation.objects.get_or_create(user=self.request.user)[0]

        resp, context = chatbot.ClientRun(form.validated_data['text'], conversation)

        return Response({
            "text": resp
        })
