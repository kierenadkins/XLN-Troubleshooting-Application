from django.db import models
from django.conf import settings


class Conversation(models.Model):
    STATE_DEFAULT = 0
    STATE_CHOICES = (
        (0, "General"),
        (1, "Waiting for yes/no"),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='+')
    state = models.IntegerField(choices=STATE_CHOICES, default=STATE_DEFAULT)


class Message(models.Model):
    conversation = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='+')
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='+')
    text = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
