import os
os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="./chatbot/APIkey.json"

from google.cloud import language_v1 as lv1
import six
import textdistance

def Sentiment(content):

    client = lv1.LanguageServiceClient()

    if isinstance(content, six.binary_type):
        content = content.decode("utf-8")

    type = lv1.Document.Type.PLAIN_TEXT
    document = {"type_": type, "content": content}

    response = client.analyze_sentiment(request={"document": document})
    sentiment = response.document_sentiment
    return sentiment.score, sentiment.magnitude

def ClientRun(userinput, conversation):
  context = 0
  if conversation is not None:
    context = conversation.state

  f = open("chatbot/Question.txt", "r", encoding="cp1252")
  Questions = f.read().split('","')
  f.close()
  f = open("chatbot/Answer.txt", "r", encoding="cp1252")
  Answers = f.read().split('","')
  f.close()

  if(context==0):
    similarities = []
    for i in range(len(Questions)):
      roSim = textdistance.ratcliff_obershelp.normalized_similarity(userinput, Questions[i])
      jwSim = textdistance.jaro_winkler.normalized_similarity(userinput, Questions[i])
      similarities.append((roSim+jwSim)/2)

    maxSimIndex = similarities.index(max(similarities))

    CurrentResp = Answers[maxSimIndex].replace(r'\n', '\n').replace('"',"")
    f = open("chatbot/CurrentResp.txt", "w")
    f.write(CurrentResp)
    f.close()

    Sent,Mag = Sentiment(userinput)

    if((Sent<-0.85 and Mag>0.8) and conversation is not None):
      conversation.state = 1
      conversation.save()
      return ("Apologises for the inconvenience caused to you by this application, would you prefer to be provided with support contact information rather than continuing with this chat? Please enter yes or no."), 1
    elif((Sent>0.2)and(Mag>0.2)):
      CurrentResp = "Thanks for your message! "+CurrentResp

    return CurrentResp, 0
  
  elif(context==1):
    if(userinput.lower() not in ["yes", "no"]):
      return("Please enter yes or no"),1
    elif(userinput.lower() == "yes"):
      conversation.state = 0
      conversation.save()
      return("Technical Support:\n0808 178 5200\n\nCustomer Service:\n0344 880 7777\n\nSales:\n0808 278 8316\n\nEmail:\nservice@telecom-service.co.uk"),0
    else:
      conversation.state = 0
      conversation.save()

      f = open("chatbot/CurrentResp.txt", "r")
      CurrentResp = f.read()
      f.close()

      return CurrentResp, 0