from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from . import models

admin.site.register(models.Service)


@admin.register(models.User)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'first_name', 'last_name', 'is_staff', )
    list_filter = ('is_staff', )
    search_fields = ('first_name', 'last_name', 'username', )
    readonly_fields = ('date_joined', 'last_login', )
    fieldsets = (
        (None, {
            'fields': ('username', 'password')
        }),
        ('Profile', {
            'fields': ('first_name', 'last_name', 'is_verified', 'is_private')
        }),
        ('Email', {
            'fields': ('email', 'email_verified')
        }),
        ('Permissions', {
            'fields': ('account_type', 'is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')
        }),
        ('Important Dates', {
            'fields': ('dob', 'last_login', 'date_joined',)
        }),
        ('Customer Details', {
            'fields': ('services',)
        }),
    )
