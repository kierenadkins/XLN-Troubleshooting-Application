from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView, TokenVerifyView
from . import views

urlpatterns = [
    path('auth/token/', views.AccountTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('auth/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('auth/token/verify/', TokenVerifyView.as_view(), name='token_verify'),
    path('auth/register/', views.CreateAccountView.as_view(), name='create_account'),
    path('auth/account/', views.UpdateAccountView.as_view(), name='update_account'),
    path('auth/register/reviewer/', views.CreateReviewerAccountView.as_view(), name='create_reviewer_account'),
    path('profile/', views.ProfileView.as_view(), name='profile'),
    path('deactivate/<str:username>/', views.DeactivateAccountView.as_view()),
    path('staff/', views.StaffView.as_view(), name="staff")
]
