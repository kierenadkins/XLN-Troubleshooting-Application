from rest_framework import generics, views
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework_simplejwt.views import TokenObtainPairView
from django.shortcuts import get_object_or_404
from .models import User
from . import serializers

class AccountTokenObtainPairView(TokenObtainPairView):
    serializer_class = serializers.AccountTokenObtainPairSerializer


class CreateAccountView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = serializers.CreateAccountSerializer


class UpdateAccountView(generics.UpdateAPIView):
    queryset = User.objects.all()
    serializer_class = serializers.CreateAccountSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user

class CreateReviewerAccountView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = serializers.CreateAccountSerializer
    def perform_create(self, serializer):
        serializer.save(is_staff=True, account_type=User.ACCOUNT_TYPE_REVIEWER)


class ProfileView(generics.RetrieveAPIView):
    serializer_class = serializers.UserSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user

        
class DeactivateAccountView(generics.DestroyAPIView):
    queryset = User.objects.all()
    serializer_class = serializers.UserSerializer
    permission_classes = [IsAdminUser]

    def get_object(self):
        queryset = self.get_queryset()
        obj = get_object_or_404(queryset, **{
            'username': self.kwargs['username']
        })

        return obj

    def perform_destroy(self, object):
        object.is_active = False
        object.save()


class StaffView(generics.ListAPIView):
    queryset = User.objects.filter(is_staff=True)
    serializer_class = serializers.UserSerializer
    permission_classes = [IsAuthenticated]

