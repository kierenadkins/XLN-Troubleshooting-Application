from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from . import models

class AccountTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token['name'] = user.get_full_name()
        token['username'] = user.username
        token['admin'] = user.is_staff
        token['account_type'] = user.account_type
        return token


class CreateAccountSerializer(serializers.ModelSerializer):
    password = serializers.CharField(
        write_only=True,
        required=True,
        style={'input_type': 'password'}
    )

    class Meta:
        model = models.User
        fields = ['id', 'first_name', 'last_name', 'username', 'email', 'email_verified', 'password']
        read_only_fields = ['email_verified']

    def create(self, validated_data):
        user = super(CreateAccountSerializer, self).create(validated_data)
        user.set_password(validated_data['password'])
        user.save()
        return user


class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Service
        fields = '__all__'


class UserSerializer(serializers.ModelSerializer):
    services = ServiceSerializer(many=True)

    class Meta:
        model = models.User
        fields = ['id', 'account_type', 'email', 'username', 'first_name', 'last_name', 'is_staff', 'services']
