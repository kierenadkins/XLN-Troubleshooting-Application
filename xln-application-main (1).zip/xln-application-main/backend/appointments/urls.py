from rest_framework import routers
from django.urls.conf import path
from . import views

router = routers.SimpleRouter()
router.register(r'appointments', views.AppointmentViewSet)

urlpatterns = router.urls
urlpatterns += [
    path("appointments/available/", views.TimeAvailableView.as_view()),
]