from rest_framework import serializers
from accounts.serializers import UserSerializer
from appointments.models import Appointment
from faults.serializers import FaultSerializer

class AppointmentSerializer(serializers.ModelSerializer):

    class Meta:
        model = Appointment
        fields = ['customer','fault', 'date', 'time', 'location1', 'location2']

class CreateAppointmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Appointment
        fields = ['customer','fault', 'date', 'time', 'location1', 'location2']
