from django.db import models
from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType

class Appointment(models.Model):
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="appointments")
    fault = models.ForeignKey('faults.Fault', on_delete=models.CASCADE, related_name="appointments")
    date = models.DateTimeField()
    time = models.CharField(max_length=50)
    location1 = models.TextField()
    location2 = models.TextField()