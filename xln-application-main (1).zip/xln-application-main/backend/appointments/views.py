from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Appointment
from faults.models import Fault
from . import serializers
from rest_framework import generics
from rest_framework.response import Response
import datetime

class AppointmentViewSet(viewsets.ModelViewSet):
    queryset = Appointment.objects.all()
    serializer_class = serializers.AppointmentSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(customer=self.request.user)

class CreateAppointmentViewSet(viewsets.ModelViewSet):
    queryset = Appointment.objects.all()
    permission_classes = [IsAuthenticated]

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return serializers.CreateAppointmentSerializer
        return serializers.AppointmentSerializer

    def perform_create(self, serializer):
        serializer.save(customer=self.request.user, fault=Fault.objects.get(id=self.request.data.get('fault')))

class TimeAvailableView(generics.GenericAPIView):
    def get(self, request, *args, **kwargs):
        date = datetime.datetime.now()
        
        hours = []

        today = Appointment.objects.filter(datetime__year=date.year, datetime__month=date.month, datetime__day=date.day)

        for hour in range(9, 5):
            available = True
            for appointment in today:
                if appointment.datetime.hour == hour:
                    available = False
            
            if available:
                hours.append(hour)

        return Response({
            "available_hours": hours
        })