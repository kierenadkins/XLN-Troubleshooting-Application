from rest_framework import viewsets
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser
from accounts.models import User
from .models import Fault, FaultResponse, Image
from . import serializers

class FaultViewSet(viewsets.ModelViewSet):
    queryset = Fault.objects.all()
    serializer_class = serializers.FaultSerializer
    permission_classes = [IsAuthenticated]

    def update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance,data = request.data)

        assigned_reviewers_ids = self.request.data.get('new_assigned_reviewers', [])
        assigned_reviewers = User.objects.filter(id__in=assigned_reviewers_ids)

        if serializer.is_valid():
            instance.assigned_reviewers.set(assigned_reviewers)
            self.perform_update(serializer)
        return Response(serializer.data)

    def perform_create(self, serializer):
        serializer.save(customer=self.request.user)


class CustomerFaultsViewSet(generics.ListAPIView):
    serializer_class = serializers.FaultSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = Fault.objects.filter(customer=self.request.user)
        return queryset


class StaffFaultsViewSet(generics.ListAPIView):
    serializer_class = serializers.FaultSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = Fault.objects.filter(assigned_reviewers__in=[self.request.user])
        return queryset

    
class FaultResponseViewSet(viewsets.ModelViewSet):
    queryset = FaultResponse.objects.all()
    serializer_class = serializers.FaultResponseSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class ImageViewSet(viewsets.ModelViewSet):
    queryset = Image.objects.all()
    serializer_class = serializers.ImageSerializer
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser]