import uuid
import datetime

def get_image_save_path(instance, filename):
    return 'uploads/{0}/{1}'.format(uuid.uuid4(), filename)
