from rest_framework import serializers
from accounts.models import User
from faults.models import FaultResponse
from . import models, utils

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'account_type', 'username', 'first_name', 'last_name']


class FaultResponseSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = FaultResponse
        fields = ['id', 'fault', 'user', 'created', 'message', 'images']

    def to_representation(self, instance):
        rep = super().to_representation(instance)
        request = self.context.get('request')
        urls = [x.file.url for x in instance.images.all()]
        rep["images"] = [request.build_absolute_uri(x) for x in urls]
        return rep


class FaultSerializer(serializers.ModelSerializer):
    customer = UserSerializer(read_only=True)
    assigned_reviewers = UserSerializer(read_only=True, many=True, allow_null=True)
    title = serializers.CharField(required=False, allow_blank=True)
    message = serializers.CharField(required=False, allow_blank=True, max_length=2000)
    service = serializers.CharField(required=True)
    type = serializers.CharField(required=True)
    responses = FaultResponseSerializer(read_only=True, many=True)

    def create(self, validated_data):
        validated_data.pop('assigned_reviewers', None)
        return super().create(validated_data)

    def to_representation(self, instance):
        rep = super().to_representation(instance)
        request = self.context.get('request')
        urls = [x.file.url for x in instance.images.all()]
        rep["images"] = [request.build_absolute_uri(x) for x in urls]
        return rep

    class Meta:
        model = models.Fault
        fields = '__all__'

class ImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Image
        fields = '__all__'
