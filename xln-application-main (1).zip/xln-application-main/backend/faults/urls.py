from rest_framework import routers
from django.urls.conf import path
from . import views

router = routers.SimpleRouter()
router.register(r'faults', views.FaultViewSet)
router.register(r'responses', views.FaultResponseViewSet)
router.register(r'images', views.ImageViewSet)


urlpatterns = router.urls
urlpatterns += [
    path('customer-faults/', views.CustomerFaultsViewSet.as_view()),
    path('staff-faults/', views.StaffFaultsViewSet.as_view())
]

