from django.db import models
from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from .utils import get_image_save_path

class Fault(models.Model):
    # STATUS_OPEN = 'open'
    STATUS_DEFAULT = 'default'
    STATUS_IN_PROGRESS = 'inProgress'
    STATUS_REVIEWED = 'reviewed'
    STATUS_DEFAULT = STATUS_DEFAULT
    STATUS_CHOICES = (
        # (STATUS_OPEN, 'Open'),
        (STATUS_DEFAULT, 'Default'),
        (STATUS_IN_PROGRESS, 'In Progress'),
        (STATUS_REVIEWED, 'Reviewed'),
    )

    PRIORITY_LOW = 1
    PRIORITY_MEDIUM = 2
    PRIORITY_HIGH = 3
    PRIORITY_CHOICES = (
        (PRIORITY_LOW, "Low"),
        (PRIORITY_MEDIUM, "Medium"),
        (PRIORITY_HIGH, "High"),
    )

    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="submitted_faults")
    assigned_reviewers = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name="assigned_faults")
    status = models.CharField(max_length=16, choices=STATUS_CHOICES, default=STATUS_DEFAULT)
    type = models.CharField(max_length=255)
    priority = models.IntegerField(choices=PRIORITY_CHOICES, default=PRIORITY_LOW)
    created = models.DateTimeField(auto_now_add=True)
    service = models.CharField(max_length=255)
    title = models.CharField(max_length=255)
    message = models.TextField()
    images = models.ManyToManyField('faults.Image', related_name="faults", blank=True)


class FaultResponse(models.Model):
    fault = models.ForeignKey('faults.Fault', on_delete=models.CASCADE, related_name="responses")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="fault_responses")
    created = models.DateTimeField(auto_now_add=True)
    message = models.TextField(blank=True)
    images = models.ManyToManyField('faults.Image', related_name="responses", blank=True)


class Image(models.Model):
    file = models.ImageField(upload_to=get_image_save_path)
    created = models.DateTimeField(auto_now_add=True)
    